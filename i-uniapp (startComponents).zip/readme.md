i-uniapp插件库 v1.0
=================



首先非常感谢uniapp小伙伴使用i-uniapp插件库来init个人/企业项目
此开源项目完全免费，维护和更新会一直做，所以欢迎提意见和疑惑，我会尽力帮助大家去解决这些问题；

写在前面：

基于uniapp的组件库，在安卓和ios各版本上得到了验证均无问题，部分特殊功能有兼容问题，这个后续会提到
运行环境： uniapp自定义组件模式/非自定义组件模式均可用
运行原理： 对uniapp原生组件进行了一层封装，以达到简洁的API更快的帮助个人/企业开始一个项目，把心思专注在业务逻辑上



* que1: 不是ui组件库，是插件库;
* que2: 需要安装的依赖有数个，包括但不限于【stylus, stylus-loader, base64的转换，iconfont，animate.css】等
* que3: 数组件UI和功能一言难尽（狗头保命），但是后续会对UI进行升级




## 使用说明：

* 请务必安装stylus, npm i stylus stylus-loader -s

* 下载插件包到本地（不要一键添加到hb中），将文件夹laoshen-startComponents放在项目中的componets下（组件文件夹下）即可，
如果出现错误，查看错误日志，一般是图标库或者是路径引起的错误





## 使用API：（按照发布时间来排序按照发布时间来排序）
* [在线文档](https://www.yinzhuoei.com/index.php/118.html)
* [github地址, 欢迎star!!](https://github.com/1018715564/i-uniapp)





